import javax.swing.*;
import java.awt.*;

public class anzeigeNachricht extends JButton
{
    private Nachricht nachricht;

    public anzeigeNachricht(Nachricht n)
    {
        this.setSize(new Dimension(100,100));
        this.setLayout(new GridLayout(2,1));
        this.setFocusPainted(false);
        this.setHorizontalAlignment(SwingConstants.LEFT);
        this.setBorder(BorderFactory.createEmptyBorder());
        this.setBackground(new Color(82, 79, 79));
        this.setForeground(new Color(0, 134, 0));
        this.setFont(new Font("Roboto", Font.BOLD, 18));
        nachricht = n;
        this.setText(nachricht.getName()+": "+nachricht.getNachricht());
    }

    public int getID()
    {
        return nachricht.getID();
    }
}

