import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Flow;

public class testingclas extends JPanel
{
    JPanel panel = new JPanel();
    JScrollPane scrollPane = new JScrollPane(panel, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

            testingclas()
    {
        setPreferredSize(new Dimension(1000,600));
        scrollPane.setBounds(0,0,1000,600);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        int counter = 0;
        List<JButton> labelList = new ArrayList<JButton>();
        for(int i=0; i<100; i++)
        {
            labelList.add(new JButton("Nummer "+i));
            if(counter==0)
            {
                labelList.get(i).setAlignmentX(RIGHT_ALIGNMENT);
                counter++;
            }
            else if(counter==1)
            {
                labelList.get(i).setAlignmentX(LEFT_ALIGNMENT);
                counter = 0;
            }
            panel.add(labelList.get(i));
        }

        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        add(scrollPane);
    }
}
