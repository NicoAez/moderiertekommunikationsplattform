import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller
{
    private ModKomView view;
    private ModKom model;

    public Controller(ModKomView mkv, ModKom mk)
    {
        view = mkv;
        model = mk;

        //ActionListener
        //
        // Achtung, aktuelles Verfahren: Beim drücken einer Nachricht wird diese Nachricht direkt an Model weitergeleitet
        // und beim topPanel zum "A" geschaltet. Dort wird beim drücken von z.B. ban einfach über den Controller die
        // Methode ban() aufgerufen, dort wird dann mit der zuvor weitergeleiteten Nachricht gearbeitet
        // NOTE: Übergabe von Nachrichten noch lange nicht implementiert, rest wsl davor schon weil 187
        //
        // Auch bei slow() sollte das Model wissen, welcher Chat gerade ausgewählt ist, indem man bei wechseln von
        // von Chats dies dem Model mitteilt
        //
        this.view.alCloseButton(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                System.exit(1);
            }
        });
        this.view.alBanButton(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                model.ban();
                view.switchTopPane(0);
            }
        });
        this.view.alUnbanButton(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                model.unban();
                view.switchTopPane(0);
            }
        });
        this.view.alDeleteButton(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                model.delete();
                view.switchTopPane(0);
            }
        });
        this.view.alModButton(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                model.modOnly();
                view.switchTopPane(1); // test (1) normalerweise (0)
            }
        });
    }

}
