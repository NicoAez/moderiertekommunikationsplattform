import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class testingclass extends JPanel
{
    JPanel panel = new JPanel();
    JScrollPane scrollPane = new JScrollPane();

    testingclass()
    {
        setLayout(new BorderLayout());
        setSize(new Dimension(1000,600));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        int counter = 0;
        List<JButton> labelList = new ArrayList<JButton>();
        for(int i=0; i<100; i++)
        {
            labelList.add(new JButton("Nummer "+i));
            if(counter==0)
            {
                labelList.get(i).setAlignmentX(RIGHT_ALIGNMENT);
                counter++;
            }
            else if(counter==1)
            {
                labelList.get(i).setAlignmentX(LEFT_ALIGNMENT);
                counter = 0;
            }
            panel.add(labelList.get(i));
        }

        scrollPane.setViewportView(panel);
        add(scrollPane);
        add(panel);
    }
}
