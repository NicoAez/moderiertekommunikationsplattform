import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class ModKom implements Observer
{
    public List<Chat> chat;
    public simulierteDatenbank datenbank;
    private int uid;
    private String name;
    private int cid;
    private Nachricht aktuelleNachricht;

    public ModKom(simulierteDatenbank d, List<Chat> c)
    {
        datenbank = d;
        chat = c;

        //TEST
        cid = 0;
        uid = 1337;
    }

    @Override
    public void update(Observable o, Object arg)
    {

    }

    public void registrieren()
    {
        for(int i = 0; i<chat.size(); i++)
        {
            chat.get(i).registrieren(this);
        }
    }
    public void anmelden(String n, String p)
    {
        uid = datenbank.anmelden(n,p);
        name = datenbank.getName(uid);
    }
    public void addNachricht(String s)
    {
        for(int i = 0; i<chat.size(); i++)
        {
            if(chat.get(i).getID()==cid)
            {
                chat.get(i).addNachricht(new Nachricht(name, uid, s));
            }
        }
    }
    public void ban()
    {
        for(int i = 0; i<chat.size(); i++)
        {
            if(chat.get(i).getID()==cid)
            {
                chat.get(i).addBan(aktuelleNachricht.getID(), uid);
            }
        }
    }
    public void unban()
    {
        for(int i = 0; i<chat.size(); i++)
        {
            if(chat.get(i).getID()==cid)
            {
                chat.get(i).deleteBan(aktuelleNachricht.getID(), uid);
            }
        }
    }
    public void delete()
    {
        for(int i = 0; i<chat.size(); i++)
        {
            if(chat.get(i).getID()==cid)
            {
                chat.get(i).deleteMessage(aktuelleNachricht, uid);
            }
        }
    }
    public void modOnly()
    {
        for(int i = 0; i<chat.size(); i++)
        {
            if(chat.get(i).getID()==cid)
            {
                chat.get(i).modModus(uid);
            }
        }
    }

}
