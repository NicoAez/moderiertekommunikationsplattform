import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class anzeigeChat extends JPanel
{
    JScrollPane scrollPane = new JScrollPane();
    JPanel panel = new JPanel();
    GridBagConstraints c = new GridBagConstraints();

    public anzeigeChat()
    {
        setLayout(new BorderLayout());
        setSize(new Dimension(1000,600));
        panel.setSize(new Dimension(1000,600));
        panel.setBackground(new Color(255, 168, 168));
        scrollPane.getVerticalScrollBar().setUnitIncrement(50);

        panel.setLayout(new GridBagLayout());

        c.insets = new Insets(5,5,5,5);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1.0;

        String testString = "omgwaseinlangerundwilderstringdernurdazudaistumzuschauenwaspassiertwenndertexteinfachmassiv zu lang ist für das panel" +
                "und deren maxima um vieles überschreitet, ja genau das will ich hiermit herrausfinden und werde dann sehen, was ich dagegen tun" +
                "kann! wünscht mir bitte viel glück und vielleicht geschieht der zeilenumbruch auf magischerweise ja irgendwie von alleine ohne" +
                "das ich noch viel einstellen muss das wäre natürlich HYPERWILD"; // :(
        int counterRL = 0;
        int counter = 0;
        List<JButton> labelList = new ArrayList<JButton>();
        for(int i=0; i<100; i++)
        {
            labelList.add(new JButton("Nummer "+i+" "+testString));
            if(counterRL==0)
            {
                c.anchor = GridBagConstraints.WEST;
                c.gridx = 0;
                c.gridy = counter;
                panel.add(labelList.get(i), c);
                counterRL++;
                counter++;
            }
            else if(counterRL==1)
            {
                c.anchor = GridBagConstraints.EAST;
                c.gridx = 1;
                c.gridy = counter;
                panel.add(labelList.get(i), c);
                counterRL = 0;
                counter++;
            }
        }
        scrollPane.setViewportView(panel);
        add(scrollPane);
    }
}
