import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.*;
import java.util.List;

public class ModKomView extends JFrame
{
    //Panels
    private List<anzeigeChat> chatCard = new ArrayList<anzeigeChat>(); // JPanels für Chats [!] evtl. Austausch durch "Chat" als Pane itsself (zukunft)
    private JPanel leftPane = new JPanel(); // Panel links für die Knöpfe
    private JPanel chatPane = new JPanel(); // Panel für die Chats
    private JTabbedPane topPane = new JTabbedPane(); // temporär tabbedPane
    private JPanel topPaneS = new JPanel(); // standard top panel
    private JPanel topPaneA = new JPanel(); // top panel mit erweiterten Funktionen, nach Auswahl einer Nachricht
    private JPanel viewPane = new JPanel(); // Panel mit cardLayout für Anmelde- und das normale Panel
    private JPanel panel = new JPanel(); // standard panel
    private JPanel anmeldePane = new JPanel(); // anmelde panel
    //Buttons
    private List<JButton> button = new ArrayList<JButton>(); // Buttons zum Auswahl der Chats
    private JButton closeButtonA = new JButton();
    private JButton closeButtonS = new JButton();
    private JButton banButton = new JButton("ban");
    private JButton unbanButton = new JButton("unban");
    private JButton deleteButton = new JButton("loeschen");
    private JButton modModeButton = new JButton("mod only mode");
    //function
    public static Point punkt;     // Schönheit ohne Rand bedeutet auch kein click and drag
    public static Point aktuell;   // deshalb fügen wir es hinzu :flushed:

    public ModKomView(int anzahlChat)
    {
        //allgemein
        this.setResizable(false);
        this.setSize(new Dimension(1300,800));
        this.setTitle("MODKOM | moderierte Kommunikationsplattform");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());
        this.setUndecorated(true);
        //abhängig
        for(int i = 0; i<anzahlChat; i++)
        {
            chatCard.add(new anzeigeChat());
            button.add(new JButton());
            button.get(i).setPreferredSize(new Dimension(10,10));
            button.get(i).setText("Chat "+(i+1));
        }
        //buttons
        closeButtonA.setPreferredSize(new Dimension(50,50));
        closeButtonA.setBackground(new Color(255, 0, 0));
        closeButtonA.setBorderPainted(false);
        closeButtonA.setFont(new Font("Roboto", Font.BOLD, 20));
        closeButtonA.setText("X");

        closeButtonS.setPreferredSize(new Dimension(50,50));
        closeButtonS.setBackground(new Color(255, 0, 0));
        closeButtonS.setBorderPainted(false);
        closeButtonS.setFont(new Font("Roboto", Font.BOLD, 20));
        closeButtonS.setText("X");

        banButton.setPreferredSize(new Dimension(100,50));
        banButton.setBorderPainted(false);

        unbanButton.setPreferredSize(new Dimension(100,50));
        unbanButton.setBorderPainted(false);

        deleteButton.setPreferredSize(new Dimension(100,50));
        deleteButton.setBorderPainted(false);

        modModeButton.setPreferredSize(new Dimension(100,50));
        modModeButton.setBorderPainted(false);

        //panel
        panel.setPreferredSize(new Dimension(1300,800));
        panel.setLayout(new BorderLayout());
        this.add(panel);
        //topPaneS
        topPaneS.setLayout(new FlowLayout()); // vorerst FlowLayout, aus designgründen später wsl. was anderes
        topPaneS.setPreferredSize(new Dimension(1300,50));
        topPaneS.add(modModeButton);
        topPaneS.add(closeButtonS);
        //topPaneA
        topPaneA.setLayout(new FlowLayout()); // siehe oben
        topPaneA.setPreferredSize(new Dimension(1300,50));
        topPaneA.add(banButton);
        topPaneA.add(unbanButton);
        topPaneA.add(deleteButton);
        topPaneA.add(closeButtonA);
        //topPane
        topPane.setLayout(new CardLayout());
        topPane.add("S", topPaneS);
        topPane.add("A", topPaneA);
        panel.add(topPane, BorderLayout.NORTH);
        //leftPane
        leftPane.setLayout(new GridLayout(button.size(),1));
        leftPane.setPreferredSize(new Dimension(300,600));
        for(int i = 0; i<button.size(); i++)
        {
            leftPane.add(button.get(i));
        }
        panel.add(leftPane, BorderLayout.WEST);
        //chatCard
        chatPane.setLayout(new CardLayout());
        chatPane.setPreferredSize(new Dimension(1000,600));
        for(int i = 0; i<chatCard.size(); i++)
        {
            chatPane.add(chatCard.get(i));
        }
        panel.add(chatPane, BorderLayout.EAST);

        //function [!] wird in Controller verschoben
        topPane.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e){}
            @Override
            public void mousePressed(MouseEvent e){punkt = e.getPoint();}
            @Override
            public void mouseReleased(MouseEvent e){punkt = null;}
            @Override
            public void mouseEntered(MouseEvent e){}
            @Override
            public void mouseExited(MouseEvent e){}
        });
        topPane.addMouseMotionListener(new MouseMotionListener() {
            @Override
            public void mouseDragged(MouseEvent event)
            {
                aktuell = event.getLocationOnScreen();
                ModKomView.super.setLocation(aktuell.x - punkt.x, aktuell.y - punkt.y);
            }
            @Override
            public void mouseMoved(MouseEvent e){}
        });
        //end
        this.setVisible(true);
    }

    //Methoden
    void switchTopPane(int i)
    {
        if(i==1)
        {
            topPane.setSelectedComponent(topPaneA);
        }
        else
        {
            topPane.setSelectedComponent(topPaneS);
        }
    }
    //ActionListener
    void alCloseButton(ActionListener al)
    {
        closeButtonA.addActionListener(al);
        closeButtonS.addActionListener(al);
    }
    void alBanButton(ActionListener al)
    {
        banButton.addActionListener(al);
    }
    void alUnbanButton(ActionListener al)
    {
        unbanButton.addActionListener(al);
    }
    void alDeleteButton(ActionListener al)
    {
        deleteButton.addActionListener(al);
    }
    void alModButton(ActionListener al)
    {
        modModeButton.addActionListener(al);
    }
}
