import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Test extends JFrame
{
    static Test instance = new Test();
    static anzeigeNachricht an = new anzeigeNachricht(new Nachricht("Nico", 187, "Ich mag 187 wirklich sehr gerne!"));
    static anzeigeChat ac = new anzeigeChat();
    static testingclass tc = new testingclass();
    public static void main(String args[])
    {
        instance.setSize(new Dimension(1000,1000));
        List<Nachricht> n = new ArrayList<Nachricht>();
        n.add(new Nachricht("Bernd", 18, "ich habe gewonnen"));
        n.add(new Nachricht("Nico", 187, "ok wie cool ist das denn"));
        n.add(new Nachricht("Bernd", 18, "ik sau cool ge"));
        n.add(new Nachricht("Deniz", 17, "ok ihr cringe lords"));
        n.add(new Nachricht("Anton", 87, ";)"));
        //ac.update(n);
        //instance.setLayout(new BorderLayout());
        //instance.add(ac, BorderLayout.NORTH);
        //instance.add(an, BorderLayout.SOUTH);
        instance.add(tc);
        instance.setVisible(true);
    }
}
